/**
 *    author:  bd26
 *    created: November 19, 2022 12:09 AM
**/

#include <bits/stdc++.h>
using namespace std;

#define all(v) (v).begin(),(v).end()
#define fori(i,n) for (int i = 0; i < n; i++)

int main(){

  ios_base::sync_with_stdio(false);
  cin.tie(NULL);

  vector <int> v(5);
  fori(i, 5){
    cin >> v[i];
  }
  sort(all(v));

  fori(j,5){
    cout << v[j] << " ";
  }

  return 0;
}
