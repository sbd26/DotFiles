function f(){
  var x = 10;
  var y = 20;
  return x + y;
}

